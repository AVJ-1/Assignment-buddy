ASSIGNMENT BUDDY — CALENDAR ALERT UPDATE

This package contains index.html with calendar export support.

UPDATE YOUR EXISTING GITHUB PAGES WEBSITE (no new repository needed):
1. Download this ZIP and extract it on your computer.
2. Open your existing assignment-buddy repository on GitHub.
3. Click Add file > Upload files.
4. Upload the new index.html from this ZIP. If GitHub says a file with that name already exists, uploading it and committing changes replaces the old version.
5. Click Commit changes.
6. Wait a few minutes, then reopen your website. If it still shows the old version, refresh the page or close and reopen the Home Screen web app.

HOW TO ADD DEADLINES TO IPHONE CALENDAR:
- For one assignment, tap the small calendar icon on its card. This downloads an .ics calendar file for that assignment.
- To export all uncompleted assignments, tap Export calendar near the top of the Upcoming view.
- On iPhone, open the downloaded .ics file (usually from Safari's Downloads / Files), then use Add All / Add to Calendar if offered.
- The calendar file includes alerts for one day before and one hour before. After importing, open the event in Calendar and confirm its alerts; if they did not import, set an alert manually.

NOTES:
- Calendar alerts are managed by Apple's Calendar app and can appear even when Assignment Buddy is closed, once the event is imported and alerts are enabled.
- This is an export/import, not automatic two-way sync. If you change a due date in Assignment Buddy, export/import the updated event again and remove the old calendar event to avoid duplicates.
- Assignments remain stored in local browser storage on that device. Do not clear browser data if you want to keep your list.
- The GitHub repository/site is public, but this app does not upload assignment data to GitHub; it stays in your browser unless you share/export it.
