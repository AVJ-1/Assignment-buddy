ASSIGNMENT BUDDY — FREE WEBSITE DEPLOYMENT

IMPORTANT: The HTML preview/download inside ChatGPT may not execute JavaScript. The buttons work when the file is served as a website.

PUBLISH FREE USING GITHUB PAGES (browser only; no app installation):
1. Sign in or create a GitHub account at https://github.com/ (this is done in your browser).
2. Go to https://github.com/new
3. Repository name: assignment-buddy
4. Choose Public, then click Create repository. Do not upload any personal assignments or private data; upload only the app file.
5. In the new repository, choose Add file > Upload files. Upload this index.html file from this ZIP, then click Commit changes. Make sure index.html is at the repository root.
6. Open Settings > Pages. Under Build and deployment, choose Deploy from a branch; select branch main and folder /(root), then Save.
7. Wait a few minutes. Your site will be at https://YOUR-GITHUB-USERNAME.github.io/assignment-buddy/ (replace YOUR-GITHUB-USERNAME with your GitHub username).

USAGE / LIMITATIONS:
- The app stores assignments in local storage in that browser on that device. It does not sync across devices.
- Do not clear the browser's site data if you want to keep assignments.
- Browser notifications need permission and work best on the published HTTPS website. Automatic checks only run while the page is open; this static site cannot guarantee reminders after the browser is fully closed.
- The GitHub repository and published site are public. The assignments you enter later stay in your own browser and are not uploaded by this app.
